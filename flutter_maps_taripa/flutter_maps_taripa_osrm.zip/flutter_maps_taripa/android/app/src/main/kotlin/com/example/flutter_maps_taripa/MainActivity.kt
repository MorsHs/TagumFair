package com.example.flutter_maps_taripa

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
