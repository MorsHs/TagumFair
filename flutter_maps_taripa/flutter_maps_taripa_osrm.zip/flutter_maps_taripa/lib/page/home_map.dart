import 'package:flutter/material.dart';
import 'package:flutter_maps_taripa/controller_animation/map.dart';

class HomeMap extends StatelessWidget {
  const HomeMap({super.key});

  @override
  Widget build(BuildContext context) {
    return MapView();
  }
}
