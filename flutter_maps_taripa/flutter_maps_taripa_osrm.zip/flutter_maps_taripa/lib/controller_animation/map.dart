import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:flutter_map/flutter_map.dart';
import 'package:flutter_maps_taripa/Shards/center_dot.dart';
import 'package:flutter_maps_taripa/Shards/locationList.dart';
import 'package:flutter_maps_taripa/Shards/marker_layers.dart';
import 'package:http/http.dart' as http;
import 'package:latlong2/latlong.dart';

class MapView extends StatefulWidget {
  const MapView({super.key});

  @override
  State<MapView> createState() => _MapViewState();
}

class _MapViewState extends State<MapView> {
  List<Location> locs = [];
  final double tagumLat = 7.448212;
  final double tagumLong = 125.809425;
  LatLng blue = LatLng(0, 0);
  LatLng red = LatLng(0, 0);
  List<double> poly = [];

  final mapController = MapController();
  void setBlue() {
    blue =
        LatLng(mapController.center.latitude, mapController.center.longitude);
  }

  getBlue() {
    return this.blue;
  }

  getBlueLat() {
    return blue.latitude;
  }

  getBlueLong() {
    return blue.longitude;
  }

  void setRed() {
    red = LatLng(mapController.center.latitude, mapController.center.longitude);
  }

  getRed() {
    return this.red;
  }

  getRedLat() {
    return this.red.latitude;
  }

  getRedLong() {
    return red.longitude;
  }

  Future getPolyLine(
      double getBLong, double getBLat, double getRLong, double getRLat) async {
    var response = await http.get(Uri.http('router.project-osrm.org',
        '/route/v1/driving/$getBLong,$getBLat;$getRLong,$getRLat?steps=true&geometries=polyline'));
    //overview=simplified&steps=true&annotations=true&geometries=geojson FIX LATER
    var jsonData = jsonDecode(response.body);
    for (var eachlocation in jsonData['steps']) {
      final hops = Location(
          location: eachlocation['location'].toString(),
          distance: eachlocation['distance'].toString());
      locs.add(hops);
    }
    print(locs.length);
  }
  /*Future getPolyLine(
      double blueLong, double blueLat, double redLong, double redLat) async {

    var response = await http.get(Uri.http(
        'router.project-osrm.org/route/v1/driving/$blueLong,$blueLat;$redLong,$redLat?overview=false'));
    var jsonData = jsonDecode(response.body);
    setState(() {
      routepoints = jsonData['location'];
    });
    print(jsonData);

    print('http://router.project-osrm.org/route/v1/driving/$getBlueLong,$getBlueLat;$getRedLong,$getRedLat?overview=false');
    print(response.body);
    print(getBlue());
    print(getRed());
    print(getBlueLong());
    print(getBlueLat());
    print(getRedLong());
    print(getRedLat());
  }*/

  void testPoly(double blueLong) {
    // print('http://router.project-osrm.org/route/v1/driving/$getBlueLong(),$getBlueLat();$getRedLong(),$getRedLat()?overview=false');
    print("object $blueLong");
  }

  List<LatLng> routepoints = [
    LatLng(0, 0)
  ]; //initialize value temporary. will change later after clicking car button
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Expanded(
          child: FlutterMap(
            options: MapOptions(
                /* onPositionChanged: (position, hasGesture) {
                  setState(() {
                    lats = LatLng(
                        position.center!.latitude, position.center!.longitude);
                    print(lats);
                  });
                },*/
                initialCenter: LatLng(tagumLat, tagumLong),
                applyPointerTranslucencyToLayers: true,
                maxZoom: 20,
                minZoom: 10,
                keepAlive: true,
                interactionOptions: InteractionOptions(
                    flags: InteractiveFlag.pinchZoom | InteractiveFlag.drag)),
            mapController: mapController,
            children: [
              TileLayer(
                urlTemplate: 'https://tile.openstreetmap.org/{z}/{x}/{y}.png',
                userAgentPackageName: 'com.example.app',
                subdomains: ['a', 'b', 'c'],
              ),
              CenterDotClass(),
              Row(
                mainAxisAlignment: MainAxisAlignment.end,
                children: [
                  Padding(
                    padding: const EdgeInsets.all(10.0),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        SizedBox(height: 300),
                        FloatingActionButton(
                          onPressed: () {
                            setState(() {
                              setBlue();
                            });
                          },
                          backgroundColor: Colors.blue,
                          child: Icon(Icons.location_on_outlined),
                        ),
                        SizedBox(height: 15),
                        FloatingActionButton(
                          onPressed: () {
                            setState(() {
                              setRed();
                            });
                          },
                          backgroundColor: Colors.blue,
                          child: Icon(Icons.location_on),
                        ),
                        SizedBox(
                          height: 15,
                        ),
                        FloatingActionButton(
                          onPressed: () {
                            getPolyLine(getBlueLong(), getBlueLat(),
                                getRedLong(), getRedLat());
                          },
                          backgroundColor: Colors.blue,
                          child: Icon(Icons.directions_car_filled),
                        )
                      ],
                    ),
                  ),
                ],
              ),
              MarkerLayerMap(
                mapController: mapController,
                blue: getBlue(),
                red: getRed(),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
