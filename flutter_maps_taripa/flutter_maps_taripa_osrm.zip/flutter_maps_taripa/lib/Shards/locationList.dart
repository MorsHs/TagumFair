class Location {
  final String location;
  final String distance;

  Location({required this.location, required this.distance});
}
