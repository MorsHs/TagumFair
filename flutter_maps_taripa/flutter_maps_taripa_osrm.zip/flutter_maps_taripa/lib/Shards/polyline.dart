import 'package:flutter/material.dart';

class PolyLineGuide extends StatefulWidget {
  const PolyLineGuide({super.key});

  @override
  State<PolyLineGuide> createState() => _PolyLineGuideState();
}

class _PolyLineGuideState extends State<PolyLineGuide> {
  @override
  Widget build(BuildContext context) {
    return const Placeholder();
  }
}
