import 'package:flutter/material.dart';
import 'package:flutter_map/flutter_map.dart';
import 'package:latlong2/latlong.dart';

class MarkerLayerMap extends StatefulWidget {
  final LatLng blue;
  final LatLng red;
  final MapController mapController;
  const MarkerLayerMap({
    super.key,
    required this.mapController,
    required this.blue,
    required this.red,
  });

  @override
  State<MarkerLayerMap> createState() => _MarkerLayerMapState();
}

class _MarkerLayerMapState extends State<MarkerLayerMap> {
  // LatLng latEnd = LatLng(7.4477, 125.8041);
  //LatLng latStart = LatLng(7.4472, 125.8093);

  @override
  Widget build(BuildContext context) {
    var marker = <Marker>[];
    marker = [
      Marker(
        rotate: false,
        alignment: Alignment.topCenter,
        point: widget.blue,
        child: Icon(Icons.location_on, color: Colors.blue),
      ),
      Marker(
          point: widget.red,
          rotate: false,
          alignment: Alignment.topCenter,
          child: Icon(
            Icons.location_on,
            color: Colors.red,
          ))
    ];
    return MarkerLayer(
      markers: marker,
      alignment: Alignment.center,
      rotate: true,
    );
  }
}
/*class MapPickerDialog extends StatefulWidget {
  const MapPickerDialog({
    super.key,
    required this.initialLocation,
    this.initialZoom = 5,
    this.mapSize = const Size(300, 300),
  });

  /// Initial location of the map widget.
  final LatLng initialLocation;

  /// Initial zoom level of the map widget.
  ///
  /// Defaults to 5.
  final double initialZoom;

  /// Customize the size of the map widget.
  ///
  /// Defaults to 300x300.
  final Size mapSize;

  @override
  State<MapPickerDialog> createState() => _MapPickerDialogState();
}

class _MapPickerDialogState extends State<MapPickerDialog> {
  final mapController = MapController();

  late final pickedLocation = ValueNotifier<LatLng>(widget.initialLocation);

  @override
  void dispose() {
    pickedLocation.dispose();
    mapController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      title: const Text('Pick a location'),
      content: SizedBox.fromSize(
        size: widget.mapSize,
        child: FlutterMap(
          mapController: mapController,
          options: MapOptions(
            center: widget.initialLocation,
            zoom: widget.initialZoom,
            onMapReady: () => pickedLocation.value = mapController.center,
            onPositionChanged: (_, __) {
              pickedLocation.value = mapController.center;
            },
          ),
          children: [
            TileLayer(
              urlTemplate: 'https://tile.openstreetmap.org/{z}/{x}/{y}.png',
              tileProvider: NetworkTileProvider(),
              userAgentPackageName: 'dev.fleaflet.flutter_map.example',
            ),
            ValueListenableBuilder<LatLng>(
              valueListenable: pickedLocation,
              builder: (context, location, _) {
                return MarkerLayer(
                  markers: [
                    Marker(
                      point: location,
                      child: const Icon(Icons.location_on),
                    ),
                  ],
                );
              },
            ),
          ],
        ),
      ),
      actions: [
        TextButton(
          onPressed: () => Navigator.pop(context),
          child: const Text('Cancel'),
        ),
        TextButton(
          onPressed: () => Navigator.pop(context, pickedLocation.value),
          child: const Text('OK'),
        ),
      ],
    );
  }
}*/
